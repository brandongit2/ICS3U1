/***
 * Brandon Tsang
 * March 28, 2018
 * Assignment 14.3: Loop exercises part 3
 * ICS3U1-07 | Ms. Strelkovska
 */

public class TsangB_Asgn14_3 {
    public static void main(String[] args) {
        for (int i = 1; i <= 13; i++) {
            System.out.println(i * 13);
        }
    }
}
