/***
 * Brandon Tsang
 * March 28, 2018
 * Assignment 14.1: Loop exercises part 1
 * ICS3U1-07 | Ms. Strelkovska
 */

public class TsangB_Asgn14_1 {
    public static void main(String[] args) {
        int i = 0;
        while (i != 20) {
            i += 2;
            System.out.println(i);
        }
    }
}
