/***
 * Brandon Tsang
 * March 28, 2018
 * Assignment 14.2: Loop exercises part 2
 * ICS3U1-07 | Ms. Strelkovska
 */

public class TsangB_Asgn14_2 {
    public static void main(String[] args) {
        for (int i = 0; i < 6; i++) {
            System.out.print("a ");
        }
        System.out.println("a");
    }
}
