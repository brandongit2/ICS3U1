/***
 * Brandon Tsang
 * March 28, 2018
 * Assignment 14.4: Loop exercises part 4
 * ICS3U1-07 | Ms. Strelkovska
 */

public class TsangB_Asgn14_4 {
    public static void main(String[] args) {
        for (int i = 10; i != 0; i--) {
            System.out.println(i);
        }
    }
}
