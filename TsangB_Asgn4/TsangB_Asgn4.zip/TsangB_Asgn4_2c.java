/***
 * Brandon Tsang
 * February 15, 2018
 * Assignment 4: Calculation Exercises - Part 2c
 * ICS3U6-07 | Ms. Strelkovska
 */

public class TsangB_Asgn4_2c {
    public static void main(String[] args) {
        System.out.println(((int) (Math.random() * 5) + 1) * 10);
    }
}
