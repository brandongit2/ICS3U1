/***
 * Brandon Tsang
 * February 15, 2018
 * Assignment 4: Calculation Exercises - Part 1a
 * ICS3U6-07 | Ms. Strelkovska
 */

public class TsangB_Asgn4_1a {
    public static void main(String[] args) {
        System.out.println(Math.round((1.0 / 4.0 + 10) * 100) / 100.0);
    }
}
