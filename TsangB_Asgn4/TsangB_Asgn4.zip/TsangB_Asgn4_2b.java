/***
 * Brandon Tsang
 * February 15, 2018
 * Assignment 4: Calculation Exercises - Part 2b
 * ICS3U6-07 | Ms. Strelkovska
 */

public class TsangB_Asgn4_2b {
    public static void main(String[] args) {
        System.out.println((int) (Math.random() * 5 - 4));
    }
}
