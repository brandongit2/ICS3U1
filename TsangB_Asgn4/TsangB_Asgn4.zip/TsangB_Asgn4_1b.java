/***
 * Brandon Tsang
 * February 15, 2018
 * Assignment 4: Calculation Exercises - Part 1b
 * ICS3U6-07 | Ms. Strelkovska
 */

public class TsangB_Asgn4_1b {
    public static void main(String[] args) {
        System.out.println(Math.round((Math.pow(17.3 + 0.3, 3) - ((3 + 5.3) / (1.22 / 2))) / Math.sqrt(6) * 100) / 100.0);
    }
}
